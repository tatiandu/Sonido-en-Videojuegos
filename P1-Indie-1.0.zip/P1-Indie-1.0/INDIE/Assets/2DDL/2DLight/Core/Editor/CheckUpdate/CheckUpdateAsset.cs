﻿using UnityEngine;
using System.Collections;

public class CheckUpdateAsset : ScriptableObject {
		
	public string version = "1.3.6";
	public string dateReleased = "29/09/2016";
	public string changeLog = "http://martinysa.com/2d-dynamic-lights-2ddl-changelog/";
	public string link = "http://u3d.as/asp";

}
