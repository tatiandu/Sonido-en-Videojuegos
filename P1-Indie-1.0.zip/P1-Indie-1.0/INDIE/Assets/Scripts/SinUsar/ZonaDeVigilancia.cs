﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ZonaDeVigilancia : MonoBehaviour {

    public GameObject[] enemigosEnZona;
    
}
