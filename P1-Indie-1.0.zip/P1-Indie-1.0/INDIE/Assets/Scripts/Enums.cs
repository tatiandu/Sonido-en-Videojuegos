﻿public enum Disfraz { ninguno,programador,artista,diseñador,personal,lead,guardia }
public enum Estados { patrulla, persecucion, volviendo, finTrayecto }


